document.addEventListener("DOMContentLoaded",(()=>{const e=document.querySelector(".title"),t=()=>{var t;window.innerWidth<768?e&&(void 0!==(t=e)?.style&&(t.style.fontSize=.75*t.offsetWidth+"%")):e.style.fontSize=null};window.addEventListener("resize",t),t()}));
//# sourceMappingURL=index.792ef5da.js.map
